package com.hlag.designpattern.builder;

public interface ShipmentFactory {
	void deliver();
}
