package com.hlag.inventorySystemmain;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.UUID;

import com.hlag.inventorysystem.entity.Product;
import com.hlag.inventorysystem.exception.InvalidException;
import com.hlag.inventorysystem.service.InventorySystemServiceImpl;

public class App {

	private static InventorySystemServiceImpl inventoryService = InventorySystemServiceImpl.getInstance();

	public static void main(String[] args) throws InvalidException {

		List<Product> products = new ArrayList<>();
		products.add(new Product(UUID.randomUUID(), "Laptop", "Electronic", 50000, "First-Hand"));
		products.add(new Product(UUID.randomUUID(), "Headset", "Electronic", 5000, "First-Hand"));
		products.add(new Product(UUID.randomUUID(), "PenDrive", "Electronic", 500, "First-Hand"));
		products.add(new Product(UUID.randomUUID(), "Hard-disk", "Electronic", 500000, "First-Hand"));

		System.out.println(products);

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Product ID: ");

		while (true) {
			System.out.println("\n--- Inventory Management System ---");
			System.out.println("1. Add Product");
			System.out.println("2. Get Product By ID");
			System.out.println("3. Update Product");
			System.out.println("4. Delete Product");
			System.out.println("5. View Products (Sorted by Price)");
			System.out.println("6. View Products (Sorted by Name)");
			System.out.println("7. View Products Below Price");
			System.out.println("8. Exit");
			System.out.print("Choose an option: ");

			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
			case 1:
				addProduct(inventoryService, scanner);
				break;
			case 2:
				getProductById(inventoryService, scanner);
				break;
			case 3:
				updateProduct(inventoryService, scanner);
				break;
			case 4:
				deleteProduct(inventoryService, scanner);
				break;
			case 5:
				viewProductsSortedByPrice(inventoryService);
				break;
			case 6:
				viewProductsSortedByName(inventoryService);
				break;
			case 7:
				viewProductsBelowPrice(inventoryService, scanner);
				break;
			case 8:
				System.out.println("Exiting Inventory Management System.");
				scanner.close();
				return;
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		}
	}

	private static void addProduct(InventorySystemServiceImpl inventoryService, Scanner scanner)
			throws InvalidException {
		System.out.println("\n--- Add Product ---");
		System.out.print("Enter Product Name: ");
		String name = scanner.nextLine();
		System.out.print("Enter Product Description: ");
		String description = scanner.nextLine();
		System.out.print("Enter Product Cost: ");
		double cost = scanner.nextDouble();
		System.out.print("Enter Product Quantity: ");
		int quantity = scanner.nextInt();

		Product newProduct = new Product(UUID.randomUUID(), name, description, cost, description);
		Product addedProduct = inventoryService.addUser(newProduct);

		if (addedProduct != null) {
			System.out.println("Product added successfully: " + addedProduct);
		} else {
			System.out.println("Failed to add product.");
		}
	}

	private static void getProductById(InventorySystemServiceImpl inventoryService, Scanner scanner) {
		System.out.println("\n--- Get Product By ID ---");
		System.out.print("Enter Product ID: ");
		String productId = scanner.nextLine();

		Optional<Product> product = inventoryService.getUserById(productId);
		if (product.isPresent()) {
			System.out.println(product.get());
		} else {
			System.out.println("Product not found.");
		}
	}

	private static void deleteProduct(InventorySystemServiceImpl inventoryService, Scanner scanner) {
		System.out.println("\n--- Delete Product ---");
		System.out.print("Enter Product ID: ");
		String productId = scanner.nextLine();

		boolean isDeleted = inventoryService.deleteProduct(productId);
		if (isDeleted) {
			System.out.println("Product deleted successfully.");
		} else {
			System.out.println("Product not found.");
		}
	}

	private static void viewProductsSortedByPrice(InventorySystemServiceImpl inventoryService) {
		System.out.println("\n--- Products Sorted by Price ---");
		List<Product> products = inventoryService.getProductsSortedByPrice();
		products.forEach(System.out::println);
	}

	private static void viewProductsSortedByName(InventorySystemServiceImpl inventoryService) {
		System.out.println("\n--- Products Sorted by Name ---");
		List<Product> products = inventoryService.getProductsSortedByName();
		products.forEach(System.out::println);
	}

	private static void viewProductsBelowPrice(InventorySystemServiceImpl inventoryService, Scanner scanner) {
		System.out.println("\n--- View Products Below Price ---");
		System.out.print("Enter Maximum Price: ");
		double maxPrice = scanner.nextDouble();

		List<Product> products = inventoryService.getProductsBelowPrice(maxPrice);
		products.forEach(System.out::println);
	}

	private static void updateProduct(InventorySystemServiceImpl inventoryService, Scanner scanner) {
		System.out.println("\n--- Update Product ---");
		System.out.print("Enter Product ID: ");
		String productId = scanner.nextLine();
		System.out.print("Enter New Product Name: ");
		String newName = scanner.nextLine();
		System.out.print("Enter New Product Price: ");
		double newPrice = scanner.nextDouble();

		boolean isUpdated = inventoryService.updateProduct(productId, newName, newPrice);
		if (isUpdated) {
			System.out.println("Product updated successfully.");
		} else {
			System.out.println("Product not found.");
		}
	}

}
