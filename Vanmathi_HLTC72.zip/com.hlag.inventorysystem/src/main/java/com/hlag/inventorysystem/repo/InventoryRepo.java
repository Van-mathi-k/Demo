package com.hlag.inventorysystem.repo;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.hlag.inventorysystem.entity.Product;
import com.hlag.inventorysystem.exception.InvalidException;

public interface InventoryRepo {

	public Product addUser(Product product);

	public Optional<Product> getUserById(UUID productId);

	public boolean deleteUser(UUID productId);

	public boolean updateUser(UUID productId, Product updatedProduct) throws InvalidException;

	public boolean productExists(String uniqueId);

	public List<Product> getAllProducts();

	public boolean updateProduct(Product product);

	public boolean deleteProduct(String productId);

}
